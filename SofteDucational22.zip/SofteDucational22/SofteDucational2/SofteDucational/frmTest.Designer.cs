﻿namespace SofteDucational
{
    partial class frmTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblMain = new System.Windows.Forms.TableLayoutPanel();
            this.gbRaspunsuri = new System.Windows.Forms.GroupBox();
            this.R3 = new System.Windows.Forms.RadioButton();
            this.R2 = new System.Windows.Forms.RadioButton();
            this.R1 = new System.Windows.Forms.RadioButton();
            this.tblIntrebari = new System.Windows.Forms.TableLayoutPanel();
            this.pbIntrebare2 = new System.Windows.Forms.PictureBox();
            this.pnlIIntrebare = new System.Windows.Forms.Panel();
            this.lblIntrebare = new System.Windows.Forms.Label();
            this.pbIntrebare1 = new System.Windows.Forms.PictureBox();
            this.pnlButoane = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblIntrebarea = new System.Windows.Forms.Label();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnInainte = new System.Windows.Forms.Button();
            this.btnInapoi = new System.Windows.Forms.Button();
            this.btnhome = new System.Windows.Forms.Button();
            this.tblOptiuni = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.start = new System.Windows.Forms.Button();
            this.tblMain.SuspendLayout();
            this.gbRaspunsuri.SuspendLayout();
            this.tblIntrebari.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbIntrebare2)).BeginInit();
            this.pnlIIntrebare.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbIntrebare1)).BeginInit();
            this.pnlButoane.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tblOptiuni.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblMain
            // 
            this.tblMain.ColumnCount = 3;
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.36747F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.26506F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.36747F));
            this.tblMain.Controls.Add(this.gbRaspunsuri, 1, 2);
            this.tblMain.Controls.Add(this.tblIntrebari, 1, 1);
            this.tblMain.Controls.Add(this.pnlButoane, 1, 3);
            this.tblMain.Controls.Add(this.btnhome, 0, 0);
            this.tblMain.Controls.Add(this.start, 0, 2);
            this.tblMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMain.Location = new System.Drawing.Point(0, 0);
            this.tblMain.Name = "tblMain";
            this.tblMain.RowCount = 4;
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.46572F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.38704F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.44822F));
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.69902F));
            this.tblMain.Size = new System.Drawing.Size(800, 450);
            this.tblMain.TabIndex = 0;
            // 
            // gbRaspunsuri
            // 
            this.gbRaspunsuri.Controls.Add(this.R3);
            this.gbRaspunsuri.Controls.Add(this.R2);
            this.gbRaspunsuri.Controls.Add(this.R1);
            this.gbRaspunsuri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbRaspunsuri.Location = new System.Drawing.Point(173, 258);
            this.gbRaspunsuri.MaximumSize = new System.Drawing.Size(0, 115);
            this.gbRaspunsuri.Name = "gbRaspunsuri";
            this.gbRaspunsuri.Size = new System.Drawing.Size(452, 68);
            this.gbRaspunsuri.TabIndex = 0;
            this.gbRaspunsuri.TabStop = false;
            // 
            // R3
            // 
            this.R3.AutoSize = true;
            this.R3.Dock = System.Windows.Forms.DockStyle.Left;
            this.R3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.R3.Location = new System.Drawing.Point(257, 16);
            this.R3.Name = "R3";
            this.R3.Size = new System.Drawing.Size(144, 49);
            this.R3.TabIndex = 2;
            this.R3.TabStop = true;
            this.R3.Text = "Alexandru Papiu Ilarian";
            this.R3.UseVisualStyleBackColor = true;
            // 
            // R2
            // 
            this.R2.AutoSize = true;
            this.R2.Dock = System.Windows.Forms.DockStyle.Left;
            this.R2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.R2.Location = new System.Drawing.Point(126, 16);
            this.R2.Name = "R2";
            this.R2.Size = new System.Drawing.Size(131, 49);
            this.R2.TabIndex = 1;
            this.R2.TabStop = true;
            this.R2.Text = "Alexandru Ioan Cuza";
            this.R2.UseVisualStyleBackColor = true;
            // 
            // R1
            // 
            this.R1.AutoSize = true;
            this.R1.Dock = System.Windows.Forms.DockStyle.Left;
            this.R1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.R1.Location = new System.Drawing.Point(3, 16);
            this.R1.Name = "R1";
            this.R1.Size = new System.Drawing.Size(123, 49);
            this.R1.TabIndex = 0;
            this.R1.TabStop = true;
            this.R1.Text = "Tudor Vladimirescu";
            this.R1.UseVisualStyleBackColor = true;
            // 
            // tblIntrebari
            // 
            this.tblIntrebari.ColumnCount = 2;
            this.tblIntrebari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblIntrebari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblIntrebari.Controls.Add(this.pbIntrebare2, 1, 1);
            this.tblIntrebari.Controls.Add(this.pnlIIntrebare, 0, 0);
            this.tblIntrebari.Controls.Add(this.pbIntrebare1, 0, 1);
            this.tblIntrebari.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tblIntrebari.Location = new System.Drawing.Point(173, 50);
            this.tblIntrebari.MaximumSize = new System.Drawing.Size(0, 202);
            this.tblIntrebari.Name = "tblIntrebari";
            this.tblIntrebari.RowCount = 2;
            this.tblIntrebari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblIntrebari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblIntrebari.Size = new System.Drawing.Size(452, 202);
            this.tblIntrebari.TabIndex = 1;
            // 
            // pbIntrebare2
            // 
            this.pbIntrebare2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbIntrebare2.Location = new System.Drawing.Point(229, 104);
            this.pbIntrebare2.Name = "pbIntrebare2";
            this.pbIntrebare2.Size = new System.Drawing.Size(220, 95);
            this.pbIntrebare2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbIntrebare2.TabIndex = 2;
            this.pbIntrebare2.TabStop = false;
            // 
            // pnlIIntrebare
            // 
            this.tblIntrebari.SetColumnSpan(this.pnlIIntrebare, 2);
            this.pnlIIntrebare.Controls.Add(this.lblIntrebare);
            this.pnlIIntrebare.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIIntrebare.Location = new System.Drawing.Point(3, 3);
            this.pnlIIntrebare.Name = "pnlIIntrebare";
            this.pnlIIntrebare.Size = new System.Drawing.Size(446, 95);
            this.pnlIIntrebare.TabIndex = 0;
            // 
            // lblIntrebare
            // 
            this.lblIntrebare.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIntrebare.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblIntrebare.Location = new System.Drawing.Point(0, 0);
            this.lblIntrebare.Name = "lblIntrebare";
            this.lblIntrebare.Size = new System.Drawing.Size(446, 95);
            this.lblIntrebare.TabIndex = 0;
            this.lblIntrebare.Text = "Cine a fost liderul miscarii revolutinare in transilvania?";
            // 
            // pbIntrebare1
            // 
            this.pbIntrebare1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbIntrebare1.Location = new System.Drawing.Point(3, 104);
            this.pbIntrebare1.Name = "pbIntrebare1";
            this.pbIntrebare1.Size = new System.Drawing.Size(220, 95);
            this.pbIntrebare1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbIntrebare1.TabIndex = 1;
            this.pbIntrebare1.TabStop = false;
            // 
            // pnlButoane
            // 
            this.pnlButoane.Controls.Add(this.panel1);
            this.pnlButoane.Controls.Add(this.btnVerifica);
            this.pnlButoane.Controls.Add(this.btnReset);
            this.pnlButoane.Controls.Add(this.btnInainte);
            this.pnlButoane.Controls.Add(this.btnInapoi);
            this.pnlButoane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButoane.Location = new System.Drawing.Point(173, 332);
            this.pnlButoane.MaximumSize = new System.Drawing.Size(0, 115);
            this.pnlButoane.Name = "pnlButoane";
            this.pnlButoane.Size = new System.Drawing.Size(452, 115);
            this.pnlButoane.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.lblIntrebarea);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(170, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(112, 115);
            this.panel1.TabIndex = 4;
            // 
            // lblIntrebarea
            // 
            this.lblIntrebarea.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblIntrebarea.AutoSize = true;
            this.lblIntrebarea.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblIntrebarea.Location = new System.Drawing.Point(37, 84);
            this.lblIntrebarea.Name = "lblIntrebarea";
            this.lblIntrebarea.Size = new System.Drawing.Size(39, 25);
            this.lblIntrebarea.TabIndex = 0;
            this.lblIntrebarea.Text = "1/3";
            // 
            // btnVerifica
            // 
            this.btnVerifica.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnVerifica.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnVerifica.Location = new System.Drawing.Point(282, 0);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(85, 115);
            this.btnVerifica.TabIndex = 3;
            this.btnVerifica.Text = "Verifica";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // btnReset
            // 
            this.btnReset.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnReset.Location = new System.Drawing.Point(85, 0);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(85, 115);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            // 
            // btnInainte
            // 
            this.btnInainte.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnInainte.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnInainte.Location = new System.Drawing.Point(367, 0);
            this.btnInainte.Name = "btnInainte";
            this.btnInainte.Size = new System.Drawing.Size(85, 115);
            this.btnInainte.TabIndex = 1;
            this.btnInainte.Text = "Inainte";
            this.btnInainte.UseVisualStyleBackColor = true;
            this.btnInainte.Click += new System.EventHandler(this.btnInainte_Click);
            // 
            // btnInapoi
            // 
            this.btnInapoi.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnInapoi.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnInapoi.Location = new System.Drawing.Point(0, 0);
            this.btnInapoi.Name = "btnInapoi";
            this.btnInapoi.Size = new System.Drawing.Size(85, 115);
            this.btnInapoi.TabIndex = 0;
            this.btnInapoi.Text = "Inapoi";
            this.btnInapoi.UseVisualStyleBackColor = true;
            // 
            // btnhome
            // 
            this.btnhome.BackColor = System.Drawing.Color.Red;
            this.btnhome.BackgroundImage = global::SofteDucational.Resurse.left_arrow___Copy;
            this.btnhome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnhome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnhome.FlatAppearance.BorderSize = 0;
            this.btnhome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnhome.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhome.ForeColor = System.Drawing.Color.White;
            this.btnhome.Location = new System.Drawing.Point(3, 3);
            this.btnhome.Name = "btnhome";
            this.btnhome.Size = new System.Drawing.Size(164, 41);
            this.btnhome.TabIndex = 3;
            this.btnhome.UseVisualStyleBackColor = false;
            this.btnhome.Click += new System.EventHandler(this.btnhome_Click);
            // 
            // tblOptiuni
            // 
            this.tblOptiuni.ColumnCount = 5;
            this.tblOptiuni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tblOptiuni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.41176F));
            this.tblOptiuni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.41176F));
            this.tblOptiuni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.41176F));
            this.tblOptiuni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tblOptiuni.Controls.Add(this.button1, 2, 0);
            this.tblOptiuni.Controls.Add(this.button2, 2, 1);
            this.tblOptiuni.Location = new System.Drawing.Point(368, 230);
            this.tblOptiuni.Name = "tblOptiuni";
            this.tblOptiuni.RowCount = 2;
            this.tblOptiuni.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblOptiuni.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblOptiuni.Size = new System.Drawing.Size(200, 100);
            this.tblOptiuni.TabIndex = 1;
            this.tblOptiuni.Visible = false;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button1.Location = new System.Drawing.Point(72, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(52, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Location = new System.Drawing.Point(72, 53);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(52, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(3, 258);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 4;
            this.start.Text = "button3";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // frmTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tblOptiuni);
            this.Controls.Add(this.tblMain);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTest";
            this.Text = "frmTest";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tblMain.ResumeLayout(false);
            this.gbRaspunsuri.ResumeLayout(false);
            this.gbRaspunsuri.PerformLayout();
            this.tblIntrebari.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbIntrebare2)).EndInit();
            this.pnlIIntrebare.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbIntrebare1)).EndInit();
            this.pnlButoane.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tblOptiuni.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblMain;
        private System.Windows.Forms.GroupBox gbRaspunsuri;
        private System.Windows.Forms.RadioButton R3;
        private System.Windows.Forms.RadioButton R2;
        private System.Windows.Forms.RadioButton R1;
        private System.Windows.Forms.TableLayoutPanel tblIntrebari;
        private System.Windows.Forms.PictureBox pbIntrebare2;
        private System.Windows.Forms.Panel pnlIIntrebare;
        private System.Windows.Forms.Label lblIntrebare;
        private System.Windows.Forms.PictureBox pbIntrebare1;
        private System.Windows.Forms.Panel pnlButoane;
        private System.Windows.Forms.Button btnVerifica;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnInainte;
        private System.Windows.Forms.Button btnInapoi;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblIntrebarea;
        private System.Windows.Forms.TableLayoutPanel tblOptiuni;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnhome;
        private System.Windows.Forms.Button start;
    }
}