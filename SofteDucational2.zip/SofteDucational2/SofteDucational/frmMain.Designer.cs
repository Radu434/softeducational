﻿namespace SofteDucational
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlMeniu = new System.Windows.Forms.Panel();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnProgres = new System.Windows.Forms.Button();
            this.btnBibliografie = new System.Windows.Forms.Button();
            this.btnTaraRomaneasca = new System.Windows.Forms.Button();
            this.btnMoldova = new System.Windows.Forms.Button();
            this.btnTransilvania = new System.Windows.Forms.Button();
            this.btnMeniu = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tblMain.SuspendLayout();
            this.pnlMeniu.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblMain
            // 
            this.tblMain.AutoScroll = true;
            this.tblMain.AutoScrollMargin = new System.Drawing.Size(100, 100);
            this.tblMain.BackColor = System.Drawing.Color.White;
            this.tblMain.ColumnCount = 4;
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.30976F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.31181F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.37843F));
            this.tblMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblMain.Controls.Add(this.btnTaraRomaneasca, 2, 0);
            this.tblMain.Controls.Add(this.btnMoldova, 3, 0);
            this.tblMain.Controls.Add(this.btnTransilvania, 1, 0);
            this.tblMain.Controls.Add(this.pnlMeniu, 0, 0);
            this.tblMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblMain.Location = new System.Drawing.Point(0, 0);
            this.tblMain.Name = "tblMain";
            this.tblMain.RowCount = 1;
            this.tblMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblMain.Size = new System.Drawing.Size(825, 764);
            this.tblMain.TabIndex = 0;
            this.tblMain.Paint += new System.Windows.Forms.PaintEventHandler(this.tblMain_Paint);
            // 
            // pnlMeniu
            // 
            this.pnlMeniu.Controls.Add(this.btnBibliografie);
            this.pnlMeniu.Controls.Add(this.btnProgres);
            this.pnlMeniu.Controls.Add(this.btnTest);
            this.pnlMeniu.Controls.Add(this.btnMeniu);
            this.pnlMeniu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMeniu.Location = new System.Drawing.Point(3, 3);
            this.pnlMeniu.Name = "pnlMeniu";
            this.pnlMeniu.Size = new System.Drawing.Size(64, 758);
            this.pnlMeniu.TabIndex = 0;
            this.pnlMeniu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMeniu_Paint);
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnTest.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTest.FlatAppearance.BorderSize = 0;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTest.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnTest.ForeColor = System.Drawing.Color.White;
            this.btnTest.Location = new System.Drawing.Point(0, 64);
            this.btnTest.Margin = new System.Windows.Forms.Padding(0);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(64, 63);
            this.btnTest.TabIndex = 6;
            this.btnTest.Text = "Test Grila";
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Visible = false;
            // 
            // btnProgres
            // 
            this.btnProgres.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnProgres.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProgres.FlatAppearance.BorderSize = 0;
            this.btnProgres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProgres.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnProgres.ForeColor = System.Drawing.Color.White;
            this.btnProgres.Location = new System.Drawing.Point(0, 127);
            this.btnProgres.Margin = new System.Windows.Forms.Padding(0);
            this.btnProgres.Name = "btnProgres";
            this.btnProgres.Size = new System.Drawing.Size(64, 63);
            this.btnProgres.TabIndex = 7;
            this.btnProgres.Text = "Progres";
            this.btnProgres.UseVisualStyleBackColor = false;
            this.btnProgres.Visible = false;
            // 
            // btnBibliografie
            // 
            this.btnBibliografie.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnBibliografie.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBibliografie.FlatAppearance.BorderSize = 0;
            this.btnBibliografie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBibliografie.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnBibliografie.ForeColor = System.Drawing.Color.White;
            this.btnBibliografie.Location = new System.Drawing.Point(0, 190);
            this.btnBibliografie.Margin = new System.Windows.Forms.Padding(0);
            this.btnBibliografie.Name = "btnBibliografie";
            this.btnBibliografie.Size = new System.Drawing.Size(64, 63);
            this.btnBibliografie.TabIndex = 8;
            this.btnBibliografie.Text = "Bibliografie";
            this.btnBibliografie.UseVisualStyleBackColor = false;
            this.btnBibliografie.Visible = false;
            // 
            // btnTaraRomaneasca
            // 
            this.btnTaraRomaneasca.BackColor = System.Drawing.Color.White;
            this.btnTaraRomaneasca.BackgroundImage = global::SofteDucational.Resurse.steagTaraRomaneasca;
            this.btnTaraRomaneasca.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTaraRomaneasca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTaraRomaneasca.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTaraRomaneasca.FlatAppearance.BorderSize = 0;
            this.btnTaraRomaneasca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaraRomaneasca.Font = new System.Drawing.Font("Lucida Bright", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaraRomaneasca.ForeColor = System.Drawing.Color.Black;
            this.btnTaraRomaneasca.Location = new System.Drawing.Point(324, 3);
            this.btnTaraRomaneasca.MinimumSize = new System.Drawing.Size(200, 0);
            this.btnTaraRomaneasca.Name = "btnTaraRomaneasca";
            this.btnTaraRomaneasca.Size = new System.Drawing.Size(245, 758);
            this.btnTaraRomaneasca.TabIndex = 0;
            this.btnTaraRomaneasca.Text = "Tara Romaneasca";
            this.btnTaraRomaneasca.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTaraRomaneasca.UseVisualStyleBackColor = false;
            // 
            // btnMoldova
            // 
            this.btnMoldova.BackColor = System.Drawing.Color.Maroon;
            this.btnMoldova.BackgroundImage = global::SofteDucational.Resurse.steagMoldova1;
            this.btnMoldova.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMoldova.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoldova.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMoldova.FlatAppearance.BorderSize = 0;
            this.btnMoldova.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMoldova.Font = new System.Drawing.Font("Lucida Bright", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoldova.ForeColor = System.Drawing.Color.White;
            this.btnMoldova.Location = new System.Drawing.Point(575, 3);
            this.btnMoldova.MinimumSize = new System.Drawing.Size(200, 0);
            this.btnMoldova.Name = "btnMoldova";
            this.btnMoldova.Size = new System.Drawing.Size(247, 758);
            this.btnMoldova.TabIndex = 1;
            this.btnMoldova.Text = "Moldova";
            this.btnMoldova.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMoldova.UseVisualStyleBackColor = false;
            // 
            // btnTransilvania
            // 
            this.btnTransilvania.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnTransilvania.BackgroundImage = global::SofteDucational.Resurse.steagTransilvania;
            this.btnTransilvania.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnTransilvania.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransilvania.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTransilvania.FlatAppearance.BorderSize = 0;
            this.btnTransilvania.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransilvania.Font = new System.Drawing.Font("Lucida Bright", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransilvania.ForeColor = System.Drawing.Color.White;
            this.btnTransilvania.Location = new System.Drawing.Point(73, 3);
            this.btnTransilvania.MinimumSize = new System.Drawing.Size(200, 0);
            this.btnTransilvania.Name = "btnTransilvania";
            this.btnTransilvania.Size = new System.Drawing.Size(245, 758);
            this.btnTransilvania.TabIndex = 2;
            this.btnTransilvania.Text = "Transilvania";
            this.btnTransilvania.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTransilvania.UseVisualStyleBackColor = false;
            this.btnTransilvania.Click += new System.EventHandler(this.btnTransilvania_Click);
            // 
            // btnMeniu
            // 
            this.btnMeniu.BackColor = System.Drawing.Color.Transparent;
            this.btnMeniu.BackgroundImage = global::SofteDucational.Resurse.menu;
            this.btnMeniu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMeniu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMeniu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMeniu.FlatAppearance.BorderSize = 0;
            this.btnMeniu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMeniu.Location = new System.Drawing.Point(0, 0);
            this.btnMeniu.Name = "btnMeniu";
            this.btnMeniu.Size = new System.Drawing.Size(64, 64);
            this.btnMeniu.TabIndex = 5;
            this.btnMeniu.UseVisualStyleBackColor = false;
            this.btnMeniu.Click += new System.EventHandler(this.btnMeniu_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(825, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScrollMargin = new System.Drawing.Size(0, 700);
            this.ClientSize = new System.Drawing.Size(825, 764);
            this.Controls.Add(this.tblMain);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SofteDucational";
            this.tblMain.ResumeLayout(false);
            this.pnlMeniu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnTaraRomaneasca;
        private System.Windows.Forms.Button btnMoldova;
        private System.Windows.Forms.Panel pnlMeniu;
        private System.Windows.Forms.Button btnMeniu;
        private System.Windows.Forms.Button btnProgres;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnBibliografie;
        private System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.TableLayoutPanel tblMain;
        public System.Windows.Forms.Button btnTransilvania;
    }
}

