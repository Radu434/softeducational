﻿namespace SofteDucational
{
    partial class frmTransilvania
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTransilvania));
            this.btnInapoi = new System.Windows.Forms.Button();
            this.pnlTopBar = new System.Windows.Forms.Panel();
            this.test = new System.Windows.Forms.Label();
            this.btnLectia5 = new System.Windows.Forms.Button();
            this.btnLectia4 = new System.Windows.Forms.Button();
            this.btnLectia3 = new System.Windows.Forms.Button();
            this.btnLectia2 = new System.Windows.Forms.Button();
            this.btnLectia1 = new System.Windows.Forms.Button();
            this.pnlLectii = new System.Windows.Forms.Panel();
            this.tblLectii = new System.Windows.Forms.TableLayoutPanel();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.btnPreviousPage = new System.Windows.Forms.Button();
            this.pnlText1 = new System.Windows.Forms.Panel();
            this.lblText1 = new System.Windows.Forms.Label();
            this.pnlText2 = new System.Windows.Forms.Panel();
            this.lblText2 = new System.Windows.Forms.Label();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pnlTopBar.SuspendLayout();
            this.pnlLectii.SuspendLayout();
            this.tblLectii.SuspendLayout();
            this.pnlText1.SuspendLayout();
            this.pnlText2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnInapoi
            // 
            this.btnInapoi.BackColor = System.Drawing.Color.Red;
            this.btnInapoi.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnInapoi.FlatAppearance.BorderSize = 0;
            this.btnInapoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInapoi.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnInapoi.ForeColor = System.Drawing.Color.White;
            this.btnInapoi.Location = new System.Drawing.Point(0, 0);
            this.btnInapoi.Name = "btnInapoi";
            this.btnInapoi.Size = new System.Drawing.Size(75, 52);
            this.btnInapoi.TabIndex = 0;
            this.btnInapoi.Text = "Inapoi";
            this.btnInapoi.UseVisualStyleBackColor = false;
            this.btnInapoi.Click += new System.EventHandler(this.btnInapoi_Click);
            // 
            // pnlTopBar
            // 
            this.pnlTopBar.BackColor = System.Drawing.Color.MidnightBlue;
            this.pnlTopBar.Controls.Add(this.test);
            this.pnlTopBar.Controls.Add(this.btnLectia5);
            this.pnlTopBar.Controls.Add(this.btnLectia4);
            this.pnlTopBar.Controls.Add(this.btnLectia3);
            this.pnlTopBar.Controls.Add(this.btnLectia2);
            this.pnlTopBar.Controls.Add(this.btnLectia1);
            this.pnlTopBar.Controls.Add(this.btnInapoi);
            this.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBar.Name = "pnlTopBar";
            this.pnlTopBar.Size = new System.Drawing.Size(815, 52);
            this.pnlTopBar.TabIndex = 0;
            // 
            // test
            // 
            this.test.AutoSize = true;
            this.test.ForeColor = System.Drawing.Color.White;
            this.test.Location = new System.Drawing.Point(658, 25);
            this.test.Name = "test";
            this.test.Size = new System.Drawing.Size(35, 13);
            this.test.TabIndex = 6;
            this.test.Text = "label3";
            // 
            // btnLectia5
            // 
            this.btnLectia5.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLectia5.FlatAppearance.BorderSize = 0;
            this.btnLectia5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLectia5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLectia5.ForeColor = System.Drawing.Color.White;
            this.btnLectia5.Location = new System.Drawing.Point(415, 0);
            this.btnLectia5.Name = "btnLectia5";
            this.btnLectia5.Size = new System.Drawing.Size(85, 52);
            this.btnLectia5.TabIndex = 5;
            this.btnLectia5.Text = "Lectia 5";
            this.btnLectia5.UseVisualStyleBackColor = true;
            // 
            // btnLectia4
            // 
            this.btnLectia4.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLectia4.FlatAppearance.BorderSize = 0;
            this.btnLectia4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLectia4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLectia4.ForeColor = System.Drawing.Color.White;
            this.btnLectia4.Location = new System.Drawing.Point(330, 0);
            this.btnLectia4.Name = "btnLectia4";
            this.btnLectia4.Size = new System.Drawing.Size(85, 52);
            this.btnLectia4.TabIndex = 4;
            this.btnLectia4.Text = "Lectia 4";
            this.btnLectia4.UseVisualStyleBackColor = true;
            // 
            // btnLectia3
            // 
            this.btnLectia3.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLectia3.FlatAppearance.BorderSize = 0;
            this.btnLectia3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLectia3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLectia3.ForeColor = System.Drawing.Color.White;
            this.btnLectia3.Location = new System.Drawing.Point(245, 0);
            this.btnLectia3.Name = "btnLectia3";
            this.btnLectia3.Size = new System.Drawing.Size(85, 52);
            this.btnLectia3.TabIndex = 3;
            this.btnLectia3.Text = "Lectia 3";
            this.btnLectia3.UseVisualStyleBackColor = true;
            // 
            // btnLectia2
            // 
            this.btnLectia2.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLectia2.FlatAppearance.BorderSize = 0;
            this.btnLectia2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLectia2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLectia2.ForeColor = System.Drawing.Color.White;
            this.btnLectia2.Location = new System.Drawing.Point(160, 0);
            this.btnLectia2.Name = "btnLectia2";
            this.btnLectia2.Size = new System.Drawing.Size(85, 52);
            this.btnLectia2.TabIndex = 2;
            this.btnLectia2.Text = "Lectia 2";
            this.btnLectia2.UseVisualStyleBackColor = true;
            // 
            // btnLectia1
            // 
            this.btnLectia1.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLectia1.FlatAppearance.BorderSize = 0;
            this.btnLectia1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLectia1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLectia1.ForeColor = System.Drawing.Color.White;
            this.btnLectia1.Location = new System.Drawing.Point(75, 0);
            this.btnLectia1.Name = "btnLectia1";
            this.btnLectia1.Size = new System.Drawing.Size(85, 52);
            this.btnLectia1.TabIndex = 1;
            this.btnLectia1.Text = "Lectia 1";
            this.btnLectia1.UseVisualStyleBackColor = true;
            this.btnLectia1.Click += new System.EventHandler(this.btnLectia1_Click);
            // 
            // pnlLectii
            // 
            this.pnlLectii.Controls.Add(this.tblLectii);
            this.pnlLectii.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLectii.Location = new System.Drawing.Point(0, 52);
            this.pnlLectii.Name = "pnlLectii";
            this.pnlLectii.Size = new System.Drawing.Size(815, 576);
            this.pnlLectii.TabIndex = 1;
            // 
            // tblLectii
            // 
            this.tblLectii.BackColor = System.Drawing.Color.Silver;
            this.tblLectii.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tblLectii.ColumnCount = 4;
            this.tblLectii.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.853916F));
            this.tblLectii.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.5071F));
            this.tblLectii.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.5071F));
            this.tblLectii.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.131889F));
            this.tblLectii.Controls.Add(this.btnNextPage, 3, 0);
            this.tblLectii.Controls.Add(this.btnPreviousPage, 0, 0);
            this.tblLectii.Controls.Add(this.pnlText1, 1, 0);
            this.tblLectii.Controls.Add(this.pnlText2, 2, 1);
            this.tblLectii.Controls.Add(this.pb1, 2, 0);
            this.tblLectii.Controls.Add(this.pb2, 1, 1);
            this.tblLectii.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLectii.Location = new System.Drawing.Point(0, 0);
            this.tblLectii.Name = "tblLectii";
            this.tblLectii.RowCount = 2;
            this.tblLectii.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblLectii.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblLectii.Size = new System.Drawing.Size(815, 576);
            this.tblLectii.TabIndex = 0;
            this.tblLectii.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // btnNextPage
            // 
            this.btnNextPage.BackgroundImage = global::SofteDucational.Resurse.right_arrow;
            this.btnNextPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNextPage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnNextPage.FlatAppearance.BorderSize = 0;
            this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextPage.Location = new System.Drawing.Point(759, 249);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(53, 36);
            this.btnNextPage.TabIndex = 0;
            this.btnNextPage.UseVisualStyleBackColor = true;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // btnPreviousPage
            // 
            this.btnPreviousPage.BackgroundImage = global::SofteDucational.Resurse.left_arrow___Copy;
            this.btnPreviousPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPreviousPage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnPreviousPage.FlatAppearance.BorderSize = 0;
            this.btnPreviousPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreviousPage.Image = global::SofteDucational.Resurse.left_arrow___Copy;
            this.btnPreviousPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPreviousPage.Location = new System.Drawing.Point(3, 249);
            this.btnPreviousPage.Name = "btnPreviousPage";
            this.btnPreviousPage.Size = new System.Drawing.Size(58, 36);
            this.btnPreviousPage.TabIndex = 1;
            this.btnPreviousPage.UseVisualStyleBackColor = true;
            // 
            // pnlText1
            // 
            this.pnlText1.AutoScroll = true;
            this.pnlText1.AutoScrollMargin = new System.Drawing.Size(10, 10);
            this.pnlText1.Controls.Add(this.lblText1);
            this.pnlText1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlText1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pnlText1.Location = new System.Drawing.Point(67, 3);
            this.pnlText1.Name = "pnlText1";
            this.pnlText1.Size = new System.Drawing.Size(340, 282);
            this.pnlText1.TabIndex = 2;
            // 
            // lblText1
            // 
            this.lblText1.AutoSize = true;
            this.lblText1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblText1.Location = new System.Drawing.Point(0, 0);
            this.lblText1.MaximumSize = new System.Drawing.Size(340, 0);
            this.lblText1.Name = "lblText1";
            this.lblText1.Size = new System.Drawing.Size(338, 243);
            this.lblText1.TabIndex = 0;
            this.lblText1.Text = resources.GetString("lblText1.Text");
            // 
            // pnlText2
            // 
            this.pnlText2.AutoScroll = true;
            this.pnlText2.Controls.Add(this.lblText2);
            this.pnlText2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlText2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pnlText2.Location = new System.Drawing.Point(413, 291);
            this.pnlText2.Name = "pnlText2";
            this.pnlText2.Size = new System.Drawing.Size(340, 282);
            this.pnlText2.TabIndex = 3;
            // 
            // lblText2
            // 
            this.lblText2.AutoSize = true;
            this.lblText2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblText2.Location = new System.Drawing.Point(0, 0);
            this.lblText2.MaximumSize = new System.Drawing.Size(340, 0);
            this.lblText2.Name = "lblText2";
            this.lblText2.Size = new System.Drawing.Size(337, 405);
            this.lblText2.TabIndex = 1;
            this.lblText2.Text = resources.GetString("lblText2.Text");
            // 
            // pb1
            // 
            this.pb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pb1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb1.Image = global::SofteDucational.Resurse.steagTransilvania;
            this.pb1.Location = new System.Drawing.Point(413, 3);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(340, 282);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 4;
            this.pb1.TabStop = false;
            this.pb1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pb2
            // 
            this.pb2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb2.Image = global::SofteDucational.Resurse.HartaTransilvania;
            this.pb2.Location = new System.Drawing.Point(67, 291);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(340, 282);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2.TabIndex = 5;
            this.pb2.TabStop = false;
            // 
            // frmTransilvania
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(815, 628);
            this.Controls.Add(this.pnlLectii);
            this.Controls.Add(this.pnlTopBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTransilvania";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmTransilvania";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlTopBar.ResumeLayout(false);
            this.pnlTopBar.PerformLayout();
            this.pnlLectii.ResumeLayout(false);
            this.tblLectii.ResumeLayout(false);
            this.pnlText1.ResumeLayout(false);
            this.pnlText1.PerformLayout();
            this.pnlText2.ResumeLayout(false);
            this.pnlText2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInapoi;
        private System.Windows.Forms.Panel pnlTopBar;
        private System.Windows.Forms.Panel pnlLectii;
        private System.Windows.Forms.Button btnLectia1;
        private System.Windows.Forms.Button btnLectia4;
        private System.Windows.Forms.Button btnLectia3;
        private System.Windows.Forms.Button btnLectia2;
        private System.Windows.Forms.Button btnLectia5;
        private System.Windows.Forms.TableLayoutPanel tblLectii;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Button btnPreviousPage;
        private System.Windows.Forms.Panel pnlText1;
        private System.Windows.Forms.Label lblText1;
        private System.Windows.Forms.Panel pnlText2;
        private System.Windows.Forms.Label lblText2;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.Label test;
    }
}