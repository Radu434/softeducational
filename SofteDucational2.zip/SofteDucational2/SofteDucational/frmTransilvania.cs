﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SofteDucational
{
    public partial class frmTransilvania : Form
    {
        public frmTransilvania()
        {
            InitializeComponent();
        }
        string label1 = "TextTransilvania111";
        string label2= "TextTransilvania112";
        string poza1 = "pozaTransilvania111";
        string poza2 = "pozaTransilvania112";
        int l1 = 111, l2 = 112;
        int lectiaCurenta = 0;
        int paginaCurenta = 1;
     
     
       
        
        private void btnInapoi_Click(object sender, EventArgs e)
        {
            (this.MdiParent as frmMain).tblMain.Visible = true;
            this.Hide();
       
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnLectia1_Click(object sender, EventArgs e)
        {
            l1 = 111; l2 = 112;
            label1 = "TextTransilvania"+l1.ToString();
             label2 = "TextTransilvania"+l2.ToString();
           
            lectiaCurenta = 1;
            paginaCurenta = 1;
            lblText1.Text = Resurse.TextTransilvania111;
            lblText2.Text = Resurse.TextTransilvania112;
            test.Text = label1;
        }

        private void btnNextPage_Click(object sender, EventArgs e)
        {
            if (l1 < 121)
            {
                l1 = l1 + paginaCurenta * 10;
                l2 = l2 + paginaCurenta * 10;
            }
            label1 = "TextTransilvania" + l1.ToString();
            label2 = "TextTransilvania"+ l2.ToString();
            
            test.Text = label1;
            lblText1.Text = Resurse.ResourceManager.GetString(label1);
            lblText2.Text = Resurse.ResourceManager.GetString(label2);
            
        }
    }
}
