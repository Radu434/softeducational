﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SofteDucational
{
    public partial class frmTransilvania : Form
    {
        public frmTransilvania()
        {
            InitializeComponent();
        }
     
     
       
        
        private void btnInapoi_Click(object sender, EventArgs e)
        {
            (this.MdiParent as frmMain).tblMain
            this.Close();
           // oninchideForm(EventArgs.Empty);
            
        }
    }
}
