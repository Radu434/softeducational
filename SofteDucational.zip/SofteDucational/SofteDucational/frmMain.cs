﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SofteDucational
{
    public partial class frmMain : Form
    {
        frmTransilvania formTransilvania = new frmTransilvania();
        public frmMain()
        {
            InitializeComponent();
        }
    
  
        void menuClose()
        {
            pnlMeniu.Width = 64;
            btnTest.Visible = false;
            btnBibliografie.Visible = false;
            btnProgres.Visible = false;
            menuopen = false;
        }
        void openMenu()
        {
            if(menuopen==false)
            {
                pnlMeniu.Width = 300;
                btnTest.Visible = true;
                btnBibliografie.Visible = true;
                btnProgres.Visible = true;
                menuopen = true;
            }
            else
            {
                menuClose();
            }
        }

        private void tblMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnTransilvania_Click(object sender, EventArgs e)
        {
            
      
               formTransilvania.MdiParent = this;

            formTransilvania.Size = formTransilvania.MdiParent.Size;
            formTransilvania.Show();
            formTransilvania.BringToFront();
           tblMain.SendToBack();
         
        }

        private void btnMeniu_Click(object sender, EventArgs e)
        {
            openMenu();
        }

        private void pnlMeniu_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
