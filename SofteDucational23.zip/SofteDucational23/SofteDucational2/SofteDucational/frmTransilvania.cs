﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SofteDucational
{
    public partial class frmTransilvania : Form
    {
        public frmTransilvania()
        {
            InitializeComponent();
            
        }
        string label1 = "TextTransilvania111";
        string label2= "TextTransilvania112";
        string poza1 = "pozaTransilvania111";
        string poza2 = "pozaTransilvania112";
        int l1 = 111, l2 = 112, p1=111, p2=112;
        
        int aux= 111;
        int aux2=121;
     
     
       
        
        private void btnInapoi_Click(object sender, EventArgs e)
        {
            (this.MdiParent as frmMain).tblMain.Visible = true;
            this.Hide();
       
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmTransilvania_ClientSizeChanged(object sender, EventArgs e)
        {
           // lblText1.MaximumSize = pnlText1.Size;
           // lblText2.MaximumSize = pnlText2.Size;

        }
        void schimbaLectia(int lectia, int nrpagini)
        {
       
            aux = lectia*100+11;
            aux2 = lectia*100+nrpagini*10+1;
            l1 = lectia * 100 + 11; l2 = lectia * 100 + 12;
            p1 = l1;
            p2 = l2;
          
            label1 = "TextTransilvania" + l1.ToString();
            label2 = "TextTransilvania" + l2.ToString();
            poza1 = "pozaTransilvania" + l1.ToString();
            poza2 = "pozaTransilvania" + l2.ToString();


            lblText1.Text = Resurse.ResourceManager.GetString(label1);
            lblText2.Text = Resurse.ResourceManager.GetString(label2);
            pb1.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza1);
            pb2.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza2);
         
             test.Text = "Lectia " + (l1 / 100 % 10).ToString() + " Pagina " + (l1 / 10 % 10).ToString() + " din " + (aux2 / 10 % 10).ToString();
        }
        private void btnLectia2_Click(object sender, EventArgs e)
        {
            schimbaLectia(2, 2);
        }

        private void btnLectia3_Click(object sender, EventArgs e)
        {
            lblText1.Dock = DockStyle.Bottom;

            schimbaLectia(3, 6);
        }

        private void btnLectia4_Click(object sender, EventArgs e)
        {
            lblText1.Dock = DockStyle.Top;
            schimbaLectia(4, 1);
        }

        private void btnLectia5_Click(object sender, EventArgs e)
        {
            lblText1.Dock = DockStyle.Top;
            schimbaLectia(5, 1);
        }

        private void btnLectia1_Click(object sender, EventArgs e)
        {
            lblText1.Dock = DockStyle.Top;
            schimbaLectia(1, 2);
        }

        private void btnPreviousPage_Click(object sender, EventArgs e)
        {
            if(l1>aux)
            {
                l1 = l1 - 10;
                l2 = l2 - 10;
                p1 = p1 - 10;
                p2 = p2 - 10;
            }
            label1 = "TextTransilvania" + l1.ToString();
            label2 = "TextTransilvania" + l2.ToString();
            poza1 = "pozaTransilvania" + p1.ToString();
            poza2 = "pozaTransilvania" + p2.ToString();

            test.Text = "Lectia " + (l1 / 100 % 10).ToString() + " Pagina " + (l1 / 10 % 10).ToString() + " din " + (aux2 / 10 % 10).ToString();

            lblText1.Text = Resurse.ResourceManager.GetString(label1);
            lblText2.Text = Resurse.ResourceManager.GetString(label2);
            pb1.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza1);
            pb2.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza2);
        }
  
        private void btnNextPage_Click(object sender, EventArgs e)
        {
            
            if (l1 < aux2)
            {
                l1 = l1 +10 ; 
                l2 = l2 +10 ;
                p1 = p1 + 10;
                p2 = p2 + 10;
            }
            

            label1 = "TextTransilvania" + l1.ToString();
            label2 = "TextTransilvania"+ l2.ToString();
            poza1 = "pozaTransilvania" + p1.ToString();
            poza2 = "pozaTransilvania" + p2.ToString();


             test.Text = "Lectia " + (l1 / 100 % 10).ToString() + " Pagina " + (l1 / 10 % 10).ToString() + " din " + (aux2 / 10 % 10).ToString();
     
            lblText1.Text = Resurse.ResourceManager.GetString(label1);

            lblText2.Text = Resurse.ResourceManager.GetString(label2);
            pb1.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza1);
            pb2.Image = (Bitmap)Resurse.ResourceManager.GetObject(poza2);

        }
    }
}
