﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SofteDucational
{
    public partial class frmTest : Form
    {
        public frmTest()
        {
            InitializeComponent();
        }
        int lectia = 1;
        int intrebarea = 1;
        int nrIntrebari = 3;
        string indexIntrbare = "";
        int corecte = 0;
   
        void alegeIntrebare()
        {
            int aux = lectia * 10 + intrebarea;
            indexIntrbare = "I"+aux.ToString();
            lblIntrebare.Text = resurseTest.ResourceManager.GetString(indexIntrbare);
            
            R1.Text = resurseTest.ResourceManager.GetString(("R0"+ aux  + 1).ToString());
            R2.Text = resurseTest.ResourceManager.GetString(("R0"+ aux  + 2).ToString());
            R3.Text = resurseTest.ResourceManager.GetString(("R0"+ aux  + 3).ToString());
            if(R1.Text=="")
            {
                R1.Text = resurseTest.ResourceManager.GetString(("R1" + aux + 1).ToString());
            }
            if (R2.Text == "")
            {
                R2.Text = resurseTest.ResourceManager.GetString(("R1" + aux + 2).ToString());
            }
            if (R3.Text == "")
            {
                R3.Text = resurseTest.ResourceManager.GetString(("R1" + aux + 3).ToString());
            }

        }
        void verifica()
        {
            int aux = lectia * 10 + intrebarea;
            if (R1.Checked==true)
            {
                if(R1.Text== resurseTest.ResourceManager.GetString(("R1" + aux + 1).ToString())|| R1.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 2).ToString())|| R1.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 3).ToString()))
                {
                    corecte++;
                }
            }
            if (R2.Checked == true)
            {
                if (R2.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 1).ToString()) || R2.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 2).ToString()) || R2.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 3).ToString()))
                {
                    corecte++;
                }
            }
            if (R3.Checked == true)
            {
                if (R3.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 1).ToString()) || R3.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 2).ToString()) || R3.Text == resurseTest.ResourceManager.GetString(("R1" + aux + 3).ToString()))
                {
                    corecte++;
                }
            }
        }

        void schimbaIntrebare()
        {
            if(intrebarea<nrIntrebari)
            {

              intrebarea = intrebarea+1; 
              alegeIntrebare();
                lblIntrebarea.Text = intrebarea.ToString() + "/" + nrIntrebari.ToString();

            }
            else
            {
                MessageBox.Show("Ai terminat testul!");
                
            }
        }
       
        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnhome_Click(object sender, EventArgs e)
        {
            (this.MdiParent as frmMain).tblMain.Visible = true;
            this.Hide();
        }

        private void btnInainte_Click(object sender, EventArgs e)
        {
            verifica();
            schimbaIntrebare();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ai raspuns corect la "+corecte.ToString()+" intrebari");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
             lectia = 1;
            intrebarea = 1;
             nrIntrebari = 3;
             indexIntrbare = "";
            corecte = 0;
            alegeIntrebare();
            lblIntrebarea.Text = intrebarea.ToString() + "/" + nrIntrebari.ToString();

        }
    }
}
